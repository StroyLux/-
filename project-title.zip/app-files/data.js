var APP_DATA = {
  "scenes": [
    {
      "id": "0-panorama-",
      "name": "Panorama копия",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.0821116002406832,
        "pitch": -0.02905262829701627,
        "fov": 1.2579409239652903
      },
      "linkHotspots": [
        {
          "yaw": -0.5037360527495434,
          "pitch": 0.001629409787705427,
          "rotation": 3.141592653589793,
          "target": "1-panorama1-"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.26822437939806854,
          "pitch": -0.15461007906480262,
          "title": "<font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Дачная мечта от StroyLuх.by</font></font>",
          "text": "<div bis_skin_checked=\"1\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Внутренние размеры дома 8х3</font></font></div><div bis_skin_checked=\"1\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Размеры террасы 8х2.5</font></font></font></font></div><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Утепление пола 200мм</font></font><div bis_skin_checked=\"1\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Утепление стен 150мм</font></font></font></font></div><div bis_skin_checked=\"1\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">утепление крыши 200мм</font></font></font></font></font></font></div>"
        }
      ]
    },
    {
      "id": "1-panorama1-",
      "name": "Panorama(1) копия",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.6017687093007655,
          "pitch": 0.06920608030798014,
          "rotation": 7.853981633974483,
          "target": "0-panorama-"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
